from flask import Flask, render_template, request, jsonify
import requests
import datetime

app = Flask(__name__)

API_KEY = "OW1639L6385UCYYL"
BASE_URL = "https://www.alphavantage.co/query"

# Mapping UI pair to API pair format
MARKET_MAP = {
    "USD/BRL": "USDBRL",
    "EUR/JPY": "EURJPY",
    "GBP/JPY": "GBPJPY",
    "USD/MXN": "USDMXN",
    "AUD/USD": "AUDUSD"
}

def analyze_market(pair):
    symbol = MARKET_MAP.get(pair, pair)

    params = {
        "function": "TIME_SERIES_INTRADAY",
        "symbol": symbol,
        "interval": "5min",
        "apikey": API_KEY
    }
    response = requests.get(BASE_URL, params=params)
    data = response.json()

    time_series = data.get("Time Series (5min)", {})
    if not time_series:
        return {"signal": "NO DATA", "logic": "API Error or Limit Reached"}

    # Get last 2 candles
    times = sorted(time_series.keys(), reverse=True)
    latest = time_series[times[0]]
    previous = time_series[times[1]]

    close_now = float(latest["4. close"])
    close_prev = float(previous["4. close"])

    if close_now > close_prev:
        return {"signal": "UP", "logic": "Price increasing (Candle Pattern)"}
    elif close_now < close_prev:
        return {"signal": "DOWN", "logic": "Price decreasing (Candle Pattern)"}
    else:
        return {"signal": "NEUTRAL", "logic": "No change in candle"}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/signal")
def signal():
    pair = request.args.get("pair", "EUR/JPY")
    result = analyze_market(pair)
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)